package com.example.demo.controller;

import com.example.demo.model.ResultDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Slf4j
@RestController
@RequestMapping("/api/demo")
public class DemoController {
    // 查詢結果
    //@CrossOrigin
    @RequestMapping("/queryResult")
    public ResultDTO queryResult(HttpServletRequest request, HttpServletResponse response) {
        String id = request.getSession().getId();
        response.addCookie(new Cookie("DemoSessionId", id));
        log.info(id);

        return new ResultDTO("1", "查詢結果", id);
    }
}
